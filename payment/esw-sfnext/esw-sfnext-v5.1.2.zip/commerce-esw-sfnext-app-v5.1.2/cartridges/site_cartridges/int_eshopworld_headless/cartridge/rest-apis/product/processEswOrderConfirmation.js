/* eslint-disable no-unreachable */
'use strict';

const RESTResponseMgr = require('dw/system/RESTResponseMgr');
const Transaction = require('dw/system/Transaction');
const OrderMgr = require('dw/order/OrderMgr');
const Order = require('dw/order/Order');
const logger = require('dw/system/Logger').getLogger('EShopWorld', 'OrderConfirmation');
const Request = require('server/request');
const eswHelper = require('*/cartridge/scripts/helper/eswCoreHelper').getEswHelper;
const eswControllerHelper = require('*/cartridge/scripts/helper/eswControllersHelper');

exports.processEswOrderConfirmation = function () {
    const req = new Request(request, customer, session);
    const requestBody = JSON.parse(req.body);
    const obj = JSON.parse(requestBody.Body);
    let responseJSON = {};
    let statusCode = 200;

    if (!eswHelper.isValidEswAuthorization()) {
        statusCode = 401;
        logger.error('ESW Order Confirmation Error: Authentication Token did not match');
    } else {
        responseJSON = {
            OrderNumber: obj.retailerCartId.toString(),
            EShopWorldOrderNumber: obj.eShopWorldOrderNumber.toString(),
            ResponseCode: '200',
            ResponseText: 'Success'
        };

        try {
            const ocHelper = require('*/cartridge/scripts/helper/orderConfirmationHelper').getEswOcHelper();
            const shopperCurrency = ('checkoutTotal' in obj) ? obj.checkoutTotal.shopper.currency : obj.shopperCurrencyPaymentAmount.substring(0, 3);
            const totalCheckoutAmount = ('checkoutTotal' in obj) ? obj.checkoutTotal.shopper.amount : obj.shopperCurrencyPaymentAmount.substring(3);
            const paymentCardBrand = ('paymentDetails' in obj) ? obj.paymentDetails.methodCardBrand : obj.paymentMethodCardBrand;

            ocHelper.setOverridePriceBooks(obj.deliveryCountryIso, shopperCurrency, req);

            Transaction.wrap(function () {
                const order = OrderMgr.getOrder(obj.retailerCartId);
                if (empty(order)) {
                    statusCode = 400;
                    responseJSON.ResponseCode = '400';
                    responseJSON.ResponseText = 'Order not found';
                    return;
                } else if (order.status.value === Order.ORDER_STATUS_FAILED) {
                    const result = OrderMgr.undoFailOrder(order);
                    if (result.error) {
                        statusCode = 409;
                        responseJSON.ResponseCode = '409';
                        responseJSON.ResponseText = 'Error: Inventory Reservation Failed';
                        return;
                    }
                }
                if (order.confirmationStatus.value === Order.CONFIRMATION_STATUS_CONFIRMED) {
                    statusCode = 409;
                    responseJSON.ResponseCode = '409';
                    responseJSON.ResponseText = 'Order already exists';
                    return;
                }

                if (order.status.value === Order.ORDER_STATUS_CREATED) {
                    const currentMethodID = order.shipments[0].shippingMethodID;
                    ocHelper.setApplicableShippingMethods(order, obj.deliveryOption.deliveryOption, obj.deliveryCountryIso, req, currentMethodID);
                    if ('checkoutTotal' in obj) {
                        ocHelper.updateEswOrderAttributesV3(obj, order);
                    } else {
                        ocHelper.updateEswOrderAttributesV2(obj, order);
                    }

                    const ocLineItemObject = ('lineItems' in obj) ? obj.lineItems : obj.cartItems;
                    if (ocLineItemObject != null && ocLineItemObject[0].product.productCode) {
                        // eslint-disable-next-line no-restricted-syntax, guard-for-in
                        for (let lineItem in order.productLineItems) {
                            const cartItem = eswControllerHelper.getCartItem(ocLineItemObject, order, lineItem);
                            if ('lineItems' in obj) {
                                ocHelper.updateEswOrderItemAttributesV3(obj, order.productLineItems[lineItem], cartItem);
                            } else {
                                ocHelper.updateEswOrderItemAttributesV2(obj, order.productLineItems[lineItem], cartItem);
                            }
                        }
                        if ('lineItems' in obj) {
                            ocHelper.updateOrderLevelAttrV3(obj, order);
                        }
                    }

                    ocHelper.updateShopperAddressDetails(obj.contactDetails, order);
                    ocHelper.updateEswPaymentAttributes(order, totalCheckoutAmount, paymentCardBrand, obj);
                    ocHelper.updateSfccPromotionPriceUponOrderConfirmation(order);

                    OrderMgr.placeOrder(order);
                    if (!empty(obj.shopperCheckoutExperience) && !empty(obj.shopperCheckoutExperience.registeredProfileId)) {
                        ocHelper.saveAddressinAddressBook(obj.contactDetails, obj.shopperCheckoutExperience.registeredProfileId, obj.shopperCheckoutExperience.saveAddressForNextPurchase);
                    }
                    const isKonbiniOrder = ocHelper.processKonbiniOrderConfirmation(obj, order, totalCheckoutAmount, paymentCardBrand);
                    if (typeof isKonbiniOrder === 'undefined' || !isKonbiniOrder) {
                        if (eswHelper.isEswPostOrderSyncEnabled()) {
                            order.setConfirmationStatus(Order.CONFIRMATION_STATUS_NOTCONFIRMED);
                            order.setExportStatus(Order.EXPORT_STATUS_NOTEXPORTED);
                            order.setPaymentStatus(Order.PAYMENT_STATUS_NOTPAID);
                        } else {
                            order.setConfirmationStatus(Order.CONFIRMATION_STATUS_CONFIRMED);
                            order.setExportStatus(Order.EXPORT_STATUS_READY);
                            if (eswHelper.isUpdateOrderPaymentStatusToPaidAllowed()) {
                                order.setPaymentStatus(Order.PAYMENT_STATUS_PAID);
                            }
                        }
                    }
                }
            });
        } catch (error) {
            statusCode = error.status || error.statusCode || 500;
            logger.error('ESW order confirmation failed with status {0}', statusCode);
            responseJSON.ResponseCode = statusCode.toString();
            responseJSON.ResponseText = error.message;
        }
    }

    response.setHttpHeader('X-SF-CC-ESW-Notify-Status', statusCode.toString());
    RESTResponseMgr.createSuccess(responseJSON).render();
};

exports.processEswOrderConfirmation.public = true;